import sys, numpy as np
sys.path.insert(0, '/home/claude/repro_package/src')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
from fusion_methods import fixed_weight, pca_fusion, bayesian_immerkaer, proposed_local_var

def load_gray(p):
    return np.asarray(Image.open(p).convert('L'), dtype=np.float64) / 255.0

def fuse_row(ir, vis):
    panels = [('Visible', vis), ('Infrared', ir)]
    panels.append(('Fixed-weight', fixed_weight(ir, vis)[0]))
    panels.append(('PCA', pca_fusion(ir, vis)[0]))
    panels.append(('Bayesian', bayesian_immerkaer(ir, vis)[0]))
    panels.append(('Proposed', proposed_local_var(ir, vis)[0]))
    return panels

def make_figure(rows, out, cols=('Visible','Infrared','Fixed-weight','PCA','Bayesian','Proposed')):
    nrows, ncols = len(rows), len(cols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(2.4*ncols, 2.4*nrows))
    if nrows == 1:
        axes = axes[None, :]
    for r, (label, vis_p, ir_p) in enumerate(rows):
        vis = load_gray(vis_p); ir = load_gray(ir_p)
        if vis.shape != ir.shape:
            vis = np.asarray(Image.fromarray((vis*255).astype('uint8'))
                             .resize((ir.shape[1], ir.shape[0]), Image.BILINEAR),
                             dtype=np.float64)/255.0
        panels = fuse_row(ir, vis)
        for c, (title, img) in enumerate(panels):
            ax = axes[r, c]
            ax.imshow(np.clip(img, 0, 1), cmap='gray', vmin=0, vmax=1)
            ax.set_xticks([]); ax.set_yticks([])
            if r == 0:
                ax.set_title(title, fontsize=13)
            if c == 0:
                ax.set_ylabel(label, fontsize=12)
    plt.tight_layout(pad=0.4)
    fig.savefig(out, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print('saved', out, Image.open(out).size)

R = '/home/claude/data/RoadScene'
M = '/home/claude/data/MSRS/test'

# Figure 4 — RoadScene: FLIR_06920 (daytime, top), FLIR_07747 (night, bottom)
make_figure([
    ('FLIR_06920', f'{R}/crop_LR_visible/FLIR_06920.jpg', f'{R}/cropinfrared/FLIR_06920.jpg'),
    ('FLIR_07747', f'{R}/crop_LR_visible/FLIR_07747.jpg', f'{R}/cropinfrared/FLIR_07747.jpg'),
], '/home/claude/fig4_roadscene.jpg')

# Figure 5 — MSRS daytime: 01396D (truck, top), 00237D (cyclist/pedestrian, bottom)
make_figure([
    ('01396D', f'{M}/vi/01396D.png', f'{M}/ir/01396D.png'),
    ('00237D', f'{M}/vi/00237D.png', f'{M}/ir/00237D.png'),
], '/home/claude/fig5_msrs.jpg')
