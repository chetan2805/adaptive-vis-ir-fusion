"""
Fusion quality metrics.

In-paper metrics:
    entropy (EN), mutual_information (MI, summed over sources),
    ssim_avg (SSIM of fused vs each source, averaged).

Additional metrics recommended by review:
    qabf  : Xydeas-Petrovic gradient-based fusion quality
    vif   : pixel-domain visual information fidelity (fused vs each source, averaged)
    sd    : standard deviation of the fused image (contrast)
    sf    : spatial frequency (detail/activity)

All images are float in [0, 1] unless noted. Metrics that need 8-bit data scale
internally to [0, 255].
"""

import numpy as np
from scipy.ndimage import sobel, gaussian_filter

try:
    from skimage.metrics import structural_similarity as _ssim
    _HAS_SKIMAGE = True
except Exception:                       # pragma: no cover
    _HAS_SKIMAGE = False

_EPS = 1e-12


def _to_uint8(img):
    return np.clip(np.round(img * 255.0), 0, 255).astype(np.uint8)


# --------------------------------------------------------------------------- #
# In-paper metrics
# --------------------------------------------------------------------------- #
def entropy(fused):
    """Shannon entropy (bits) of the 256-bin intensity histogram."""
    q = _to_uint8(fused)
    hist = np.bincount(q.ravel(), minlength=256).astype(np.float64)
    p = hist / (hist.sum() + _EPS)
    p = p[p > 0]
    return float(-np.sum(p * np.log2(p)))


def _mi_pair(a, b, bins=256):
    a, b = _to_uint8(a).ravel(), _to_uint8(b).ravel()
    joint, _, _ = np.histogram2d(a, b, bins=bins, range=[[0, 255], [0, 255]])
    joint = joint / (joint.sum() + _EPS)
    px = joint.sum(axis=1, keepdims=True)
    py = joint.sum(axis=0, keepdims=True)
    nz = joint > 0
    return float(np.sum(joint[nz] * np.log2(joint[nz] / (px @ py)[nz] + _EPS)))


def mutual_information(fused, ir, vis):
    """MI(F;IR) + MI(F;VIS), per Qu et al. (2002)."""
    return _mi_pair(fused, ir) + _mi_pair(fused, vis)


def ssim_avg(fused, ir, vis):
    """Mean SSIM of fused vs each source band."""
    if not _HAS_SKIMAGE:
        raise ImportError("ssim_avg requires scikit-image: pip install scikit-image")
    s_ir = _ssim(fused, ir, data_range=1.0)
    s_vis = _ssim(fused, vis, data_range=1.0)
    return float(0.5 * (s_ir + s_vis))


# --------------------------------------------------------------------------- #
# Added metrics
# --------------------------------------------------------------------------- #
def _grad(img):
    gx = sobel(img, axis=1, mode="reflect")
    gy = sobel(img, axis=0, mode="reflect")
    g = np.sqrt(gx * gx + gy * gy)
    a = np.arctan2(gy, gx + _EPS)
    return g, a


def _qabf_pair(src, fused):
    gS, aS = _grad(src)
    gF, aF = _grad(fused)
    # Relative strength and orientation preservation (Xydeas & Petrovic, 2000)
    Gsf = np.where(gS > gF, gF / (gS + _EPS), gS / (gF + _EPS))
    Asf = 1.0 - np.abs(aS - aF) / (np.pi / 2.0)
    Tg, kg, sg = 0.9994, -15.0, 0.5
    Ta, ka, sa = 0.9879, -22.0, 0.8
    Qg = Tg / (1.0 + np.exp(kg * (Gsf - sg)))
    Qa = Ta / (1.0 + np.exp(ka * (Asf - sa)))
    Q = Qg * Qa
    return Q, gS


def qabf(fused, ir, vis):
    """Xydeas-Petrovic gradient-based fusion quality metric Q^{AB/F} in [0, 1]."""
    Qaf, gA = _qabf_pair(ir, fused)
    Qbf, gB = _qabf_pair(vis, fused)
    num = np.sum(Qaf * gA + Qbf * gB)
    den = np.sum(gA + gB) + _EPS
    return float(num / den)


def _vif_pair(ref, dist, sigma_nsq=2.0):
    """Pixel-domain VIF (Sheikh & Bovik), single scale-space integration."""
    ref = ref * 255.0
    dist = dist * 255.0
    num, den = 0.0, 0.0
    for scale in range(1, 5):
        N = 2 ** (4 - scale + 1) + 1
        sd = N / 5.0
        if scale > 1:
            ref = gaussian_filter(ref, sd)[::2, ::2]
            dist = gaussian_filter(dist, sd)[::2, ::2]
        mu1 = gaussian_filter(ref, sd)
        mu2 = gaussian_filter(dist, sd)
        mu1_sq, mu2_sq, mu1_mu2 = mu1 * mu1, mu2 * mu2, mu1 * mu2
        s1 = gaussian_filter(ref * ref, sd) - mu1_sq
        s2 = gaussian_filter(dist * dist, sd) - mu2_sq
        s12 = gaussian_filter(ref * dist, sd) - mu1_mu2
        s1 = np.maximum(s1, 0.0)
        s2 = np.maximum(s2, 0.0)
        g = s12 / (s1 + _EPS)
        sv = s2 - g * s12
        g = np.where(s1 < _EPS, 0.0, g)
        sv = np.where(s1 < _EPS, s2, sv)
        sv = np.maximum(sv, _EPS)
        num += np.sum(np.log10(1.0 + g * g * s1 / (sv + sigma_nsq)))
        den += np.sum(np.log10(1.0 + s1 / sigma_nsq))
    return num / (den + _EPS)


def vif(fused, ir, vis):
    """Mean pixel-domain VIF of fused vs each source band."""
    return float(0.5 * (_vif_pair(ir, fused) + _vif_pair(vis, fused)))


def sd(fused):
    """Standard deviation (contrast) of the fused image, on the 0-255 scale."""
    return float(np.std(_to_uint8(fused).astype(np.float64)))


def sf(fused):
    """Spatial frequency (row + column activity), on the 0-255 scale."""
    f = _to_uint8(fused).astype(np.float64)
    rf = np.sqrt(np.mean(np.diff(f, axis=1) ** 2))
    cf = np.sqrt(np.mean(np.diff(f, axis=0) ** 2))
    return float(np.sqrt(rf * rf + cf * cf))


def all_metrics(fused, ir, vis):
    """Compute the full metric suite for one fused result."""
    return {
        "EN": entropy(fused),
        "MI": mutual_information(fused, ir, vis),
        "SSIM": ssim_avg(fused, ir, vis),
        "Qabf": qabf(fused, ir, vis),
        "VIF": vif(fused, ir, vis),
        "SD": sd(fused),
        "SF": sf(fused),
    }
