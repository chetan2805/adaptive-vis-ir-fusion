"""
Training-free visible-infrared fusion methods.

Implements every method evaluated in Section 10 of the manuscript:
    - fixed_weight        : 0.5*IR + 0.5*VIS (canonical baseline)
    - pca_fusion          : first-eigenvector PCA, Naidu & Raol (2008)
    - bayesian_immerkaer  : inverse-variance (precision) weighting, Eq. (5)
    - proposed_local_var  : the proposed saliency (local-variance) scheme, Eq. (3)-(4)

and two ADDITIONAL strong training-free baselines recommended by review, so the
empirical section can be widened without leaving the lightweight family:
    - gff_fusion          : guided-filtering fusion, Li, Kang & Hu (2013)
    - dwt_fusion          : discrete wavelet transform fusion (max-abs detail)

Every function takes two single-band float images in [0, 1] of identical shape
and returns (fused_image, w_ir_map) where w_ir_map is the per-pixel weight
assigned to the IR band (for methods without an explicit per-pixel weight, a
constant map is returned so weight statistics are well defined everywhere).
"""

import numpy as np

try:
    import pywt
    _HAS_PYWT = True
except Exception:                       # pragma: no cover
    _HAS_PYWT = False

from noise_estimation import immerkaer_noise_variance

_EPS = 1e-12


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _check(ir, vis):
    ir = np.asarray(ir, dtype=np.float64)
    vis = np.asarray(vis, dtype=np.float64)
    if ir.shape != vis.shape:
        raise ValueError(f"shape mismatch: IR {ir.shape} vs VIS {vis.shape}")
    return ir, vis


def _box_filter(img, r):
    """O(1)-per-pixel box mean over a (2r+1) window via scipy uniform_filter."""
    from scipy.ndimage import uniform_filter
    return uniform_filter(np.asarray(img, dtype=np.float64),
                          size=2 * r + 1, mode="reflect")


def _local_variance(img, win=15):
    """Per-pixel local variance over a win x win window (E[x^2] - E[x]^2)."""
    r = win // 2
    mean = _box_filter(img, r)
    mean_sq = _box_filter(img * img, r)
    var = np.maximum(mean_sq - mean * mean, 0.0)
    return var


# --------------------------------------------------------------------------- #
# In-paper methods
# --------------------------------------------------------------------------- #
def fixed_weight(ir, vis):
    ir, vis = _check(ir, vis)
    fused = 0.5 * ir + 0.5 * vis
    return fused, np.full(ir.shape, 0.5)


def pca_fusion(ir, vis):
    """First-eigenvector PCA fusion, normalised to a convex combination."""
    ir, vis = _check(ir, vis)
    stack = np.stack([ir.ravel(), vis.ravel()], axis=0)   # 2 x P
    cov = np.cov(stack)
    eigvals, eigvecs = np.linalg.eigh(cov)
    pc = eigvecs[:, np.argmax(eigvals)]                   # leading eigenvector
    pc = np.abs(pc)
    pc = pc / (pc.sum() + _EPS)                           # convex weights
    w_ir = float(pc[0])
    fused = w_ir * ir + (1.0 - w_ir) * vis
    return fused, np.full(ir.shape, w_ir)


def bayesian_immerkaer(ir, vis):
    """Inverse-variance (precision) weighting, Eq. (5), with Immerkaer sigma^2."""
    ir, vis = _check(ir, vis)
    var_ir = immerkaer_noise_variance(ir) + _EPS
    var_vis = immerkaer_noise_variance(vis) + _EPS
    p_ir, p_vis = 1.0 / var_ir, 1.0 / var_vis
    w_ir = p_ir / (p_ir + p_vis)
    fused = w_ir * ir + (1.0 - w_ir) * vis
    return fused, np.full(ir.shape, w_ir)


def proposed_local_var(ir, vis, win=15):
    """Proposed saliency scheme: per-pixel local-variance weights, Eq. (3)-(4)."""
    ir, vis = _check(ir, vis)
    q_ir = _local_variance(ir, win)
    q_vis = _local_variance(vis, win)
    denom = q_ir + q_vis + _EPS
    w_ir = q_ir / denom
    fused = w_ir * ir + (1.0 - w_ir) * vis
    return fused, w_ir


# --------------------------------------------------------------------------- #
# Additional training-free baselines (recommended by review)
# --------------------------------------------------------------------------- #
def _guided_filter(I, p, r, eps):
    mean_I = _box_filter(I, r)
    mean_p = _box_filter(p, r)
    corr_I = _box_filter(I * I, r)
    corr_Ip = _box_filter(I * p, r)
    var_I = corr_I - mean_I * mean_I
    cov_Ip = corr_Ip - mean_I * mean_p
    a = cov_Ip / (var_I + eps)
    b = mean_p - a * mean_I
    mean_a = _box_filter(a, r)
    mean_b = _box_filter(b, r)
    return mean_a * I + mean_b


def gff_fusion(ir, vis, r1=2, eps1=0.3, r2=7, eps2=1e-6):
    """
    Guided-filtering fusion (two-scale, saliency-guided weight refinement).

    Reference:
        S. Li, X. Kang, J. Hu, "Image fusion with guided filtering,"
        IEEE Trans. Image Processing, 22(7), 2864-2875, 2013.
    """
    ir, vis = _check(ir, vis)
    # Two-scale decomposition
    base_ir = _box_filter(ir, r2)
    base_vis = _box_filter(vis, r2)
    det_ir = ir - base_ir
    det_vis = vis - base_vis
    # Saliency from a small Laplacian magnitude, smoothed
    def saliency(x):
        lap = np.abs(x - _box_filter(x, 1))
        return _box_filter(lap, 7)
    s_ir, s_vis = saliency(ir), saliency(vis)
    p_ir = (s_ir >= s_vis).astype(np.float64)
    p_vis = 1.0 - p_ir
    # Guided-filter weight refinement (base and detail levels)
    wb_ir = _guided_filter(ir, p_ir, r2, eps2)
    wb_vis = _guided_filter(vis, p_vis, r2, eps2)
    wd_ir = _guided_filter(ir, p_ir, r1, eps1)
    wd_vis = _guided_filter(vis, p_vis, r1, eps1)
    wb_sum = wb_ir + wb_vis + _EPS
    wd_sum = wd_ir + wd_vis + _EPS
    wb_ir, wb_vis = wb_ir / wb_sum, wb_vis / wb_sum
    wd_ir, wd_vis = wd_ir / wd_sum, wd_vis / wd_sum
    fused = (wb_ir * base_ir + wb_vis * base_vis
             + wd_ir * det_ir + wd_vis * det_vis)
    fused = np.clip(fused, 0.0, 1.0)
    # Report an effective per-pixel IR weight (base-level) for weight statistics
    return fused, wb_ir


def dwt_fusion(ir, vis, wavelet="db2", level=2):
    """
    Discrete wavelet transform fusion: average approximation, max-abs detail.
    Requires PyWavelets (pip install PyWavelets).
    """
    if not _HAS_PYWT:
        raise ImportError("dwt_fusion requires PyWavelets: pip install PyWavelets")
    ir, vis = _check(ir, vis)
    cir = pywt.wavedec2(ir, wavelet, level=level)
    cvis = pywt.wavedec2(vis, wavelet, level=level)
    fused_coeffs = [0.5 * (cir[0] + cvis[0])]            # approximation: average
    for d_ir, d_vis in zip(cir[1:], cvis[1:]):           # details: max abs
        merged = []
        for a, b in zip(d_ir, d_vis):
            merged.append(np.where(np.abs(a) >= np.abs(b), a, b))
        fused_coeffs.append(tuple(merged))
    fused = pywt.waverec2(fused_coeffs, wavelet)
    fused = fused[:ir.shape[0], :ir.shape[1]]
    fused = np.clip(fused, 0.0, 1.0)
    return fused, np.full(ir.shape, 0.5)                 # no explicit IR weight


# Registry used by the evaluation harness.
METHODS = {
    "fixed_weight": fixed_weight,
    "pca": pca_fusion,
    "bayesian_immerkaer": bayesian_immerkaer,
    "proposed": proposed_local_var,
    "gff": gff_fusion,            # additional baseline
    "dwt": dwt_fusion,            # additional baseline (needs PyWavelets)
}
