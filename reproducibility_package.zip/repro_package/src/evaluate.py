"""
Evaluation harness reproducing and extending Section 10 of the manuscript.

For each dataset it:
  1. loads aligned visible/infrared pairs,
  2. runs every fusion method,
  3. computes the full metric suite + mean per-pixel IR weight + runtime,
  4. writes per-image results to CSV,
  5. prints a mean +/- std summary table per dataset,
  6. runs paired t-tests and Cohen's d_z between the proposed method and each
     baseline, and reports the saliency-vs-precision weight inversion.

Datasets (download separately, see README):
  RoadScene : https://github.com/hanna-xu/RoadScene
  MSRS      : https://github.com/Linfeng-Tang/MSRS

Expected layout (override with --vis-dir / --ir-dir):
  data/RoadScene/vi/*.png   data/RoadScene/ir/*.png
  data/MSRS/test/vi/*.png   data/MSRS/test/ir/*.png   (suffix 'D' = day, 'N' = night)

Usage examples:
  python evaluate.py --dataset roadscene --vis-dir data/RoadScene/vi --ir-dir data/RoadScene/ir
  python evaluate.py --dataset msrs --vis-dir data/MSRS/test/vi --ir-dir data/MSRS/test/ir --time-of-day day
  python evaluate.py --dataset msrs --vis-dir data/MSRS/test/vi --ir-dir data/MSRS/test/ir --time-of-day night
"""

import argparse
import os
import time
import glob
import csv

import numpy as np

try:
    from PIL import Image
except Exception as e:                   # pragma: no cover
    raise ImportError("Pillow is required: pip install Pillow") from e

from scipy import stats

from fusion_methods import METHODS
from metrics import all_metrics

_IMG_EXT = ("*.png", "*.jpg", "*.jpeg", "*.bmp", "*.tif", "*.tiff")


# --------------------------------------------------------------------------- #
# I/O
# --------------------------------------------------------------------------- #
def _list_images(d):
    files = []
    for ext in _IMG_EXT:
        files.extend(glob.glob(os.path.join(d, ext)))
    return sorted(files)


def _load_gray(path):
    return np.asarray(Image.open(path).convert("L"), dtype=np.float64) / 255.0


def _match_pairs(vis_dir, ir_dir):
    """Pair files by identical basename (stem); fall back to sorted order."""
    vis = _list_images(vis_dir)
    ir = _list_images(ir_dir)
    ir_by_stem = {os.path.splitext(os.path.basename(p))[0]: p for p in ir}
    pairs = []
    for vp in vis:
        stem = os.path.splitext(os.path.basename(vp))[0]
        if stem in ir_by_stem:
            pairs.append((stem, vp, ir_by_stem[stem]))
    if not pairs and len(vis) == len(ir):           # fallback: positional
        for vp, ip in zip(vis, ir):
            pairs.append((os.path.splitext(os.path.basename(vp))[0], vp, ip))
    return pairs


def _filter_time_of_day(pairs, tod):
    """MSRS encodes day/night in the filename suffix ('D'/'N')."""
    if tod == "all":
        return pairs
    suffix = "d" if tod == "day" else "n"
    return [p for p in pairs if p[0].rstrip("0123456789").lower().endswith(suffix)
            or p[0][-1].lower() == suffix]


# --------------------------------------------------------------------------- #
# Core evaluation
# --------------------------------------------------------------------------- #
def evaluate(pairs, methods=None, writer=None, done=None):
    methods = methods or list(METHODS.keys())
    done = done or set()
    rows = []
    for stem, vp, ip in pairs:
        if all((m, stem) in done for m in methods):
            continue
        vis = _load_gray(vp)
        ir = _load_gray(ip)
        if vis.shape != ir.shape:                   # resize VIS to IR grid
            vis = np.asarray(
                Image.fromarray((vis * 255).astype(np.uint8))
                .resize((ir.shape[1], ir.shape[0]), Image.BILINEAR),
                dtype=np.float64) / 255.0
        for m in methods:
            if (m, stem) in done:
                continue
            fn = METHODS[m]
            try:
                t0 = time.perf_counter()
                fused, w_ir = fn(ir, vis)
                rt_ms = (time.perf_counter() - t0) * 1000.0
            except ImportError as e:
                print(f"  [skip {m}] {e}")
                continue
            met = all_metrics(fused, ir, vis)
            met.update({"method": m, "image": stem,
                        "w_ir": float(np.mean(w_ir)), "runtime_ms": rt_ms})
            rows.append(met)
            if writer is not None:
                writer["w"].writerow({k: met.get(k) for k in writer["fields"]})
                writer["f"].flush()
    return rows


def summarize(rows, methods):
    metrics = ["EN", "MI", "SSIM", "Qabf", "VIF", "SD", "SF", "w_ir", "runtime_ms"]
    print(f"\n{'method':<20}" + "".join(f"{m:>12}" for m in metrics))
    print("-" * (20 + 12 * len(metrics)))
    for m in methods:
        sub = [r for r in rows if r["method"] == m]
        if not sub:
            continue
        cells = []
        for k in metrics:
            vals = np.array([r[k] for r in sub])
            cells.append(f"{vals.mean():.3f}\u00b1{vals.std():.3f}")
        print(f"{m:<20}" + "".join(f"{c:>12}" for c in cells))


def paired_stats(rows, reference="proposed"):
    """Paired t-test + Cohen's d_z of `reference` vs each other method per metric."""
    methods = sorted({r["method"] for r in rows})
    images = sorted({r["image"] for r in rows})
    by = {(r["method"], r["image"]): r for r in rows}
    print(f"\nPaired comparison ({reference} vs baseline), Cohen's d_z [p-value]:")
    for metric in ["EN", "MI", "SSIM", "Qabf", "VIF"]:
        print(f"  {metric}:")
        for m in methods:
            if m == reference:
                continue
            diffs = []
            for im in images:
                a, b = by.get((reference, im)), by.get((m, im))
                if a and b:
                    diffs.append(a[metric] - b[metric])
            if len(diffs) < 2:
                continue
            diffs = np.array(diffs)
            dz = diffs.mean() / (diffs.std(ddof=1) + 1e-12)
            try:
                _, p = stats.ttest_rel(
                    [by[(reference, im)][metric] for im in images if (m, im) in by],
                    [by[(m, im)][metric] for im in images if (m, im) in by])
            except Exception:
                p = float("nan")
            print(f"    vs {m:<20} d_z={dz:+.2f}  [p={p:.1e}]")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dataset", required=True, choices=["roadscene", "msrs"])
    ap.add_argument("--vis-dir", required=True)
    ap.add_argument("--ir-dir", required=True)
    ap.add_argument("--time-of-day", default="all", choices=["all", "day", "night"])
    ap.add_argument("--methods", nargs="*", default=None,
                    help="subset of: " + ", ".join(METHODS.keys()))
    ap.add_argument("--out", default=None, help="per-image CSV output path")
    args = ap.parse_args()

    pairs = _match_pairs(args.vis_dir, args.ir_dir)
    if args.dataset == "msrs":
        pairs = _filter_time_of_day(pairs, args.time_of_day)
    if not pairs:
        raise SystemExit("No matched image pairs found. Check --vis-dir / --ir-dir.")
    print(f"{args.dataset} ({args.time_of_day}): {len(pairs)} pairs")

    methods = args.methods or list(METHODS.keys())
    out = args.out or f"results_{args.dataset}_{args.time_of_day}.csv"
    fieldnames = ["method", "image", "EN", "MI", "SSIM", "Qabf", "VIF",
                  "SD", "SF", "w_ir", "runtime_ms"]

    # Resume support: skip (method, image) pairs already present in the CSV.
    done = set()
    file_exists = os.path.exists(out)
    if file_exists:
        with open(out, newline="") as f:
            for r in csv.DictReader(f):
                done.add((r["method"], r["image"]))
        print(f"resuming: {len(done)} (method,image) results already on disk")

    f = open(out, "a", newline="")
    w = csv.DictWriter(f, fieldnames=fieldnames)
    if not file_exists:
        w.writeheader()
        f.flush()
    writer = {"w": w, "f": f, "fields": fieldnames}

    evaluate(pairs, methods, writer=writer, done=done)
    f.close()

    # Reload everything from disk for a complete summary.
    rows = []
    with open(out, newline="") as fh:
        for r in csv.DictReader(fh):
            for k in ["EN", "MI", "SSIM", "Qabf", "VIF", "SD", "SF",
                      "w_ir", "runtime_ms"]:
                r[k] = float(r[k])
            rows.append(r)
    n_imgs = len({r["image"] for r in rows})
    print(f"\n{n_imgs} images complete in {out}")
    summarize(rows, methods)
    paired_stats(rows)


if __name__ == "__main__":
    main()
