"""
Reproduces Figure 3 of the manuscript: closed-loop convergence simulation for
the proportional feedback formulation of Eq. (6).

Model (exactly as stated in Section 6.3):
    Q_F(k+1) = Q_F(k) + K * [Q_ref - Q_F(k)],   K = 0.18,  Q_ref = 1.

This is a first-order linear recursion; the error e(k) = Q_ref - Q_F(k)
satisfies e(k+1) = (1-K) e(k), giving monotonic geometric decay for 0 < K < 1.
The figure illustrates that conservative proportional feedback converges without
oscillation; it is NOT a stability proof for the full nonlinear controller.

Run:  python make_figure3_closedloop.py --out figure3_closedloop.png
"""

import argparse
import numpy as np
import matplotlib.pyplot as plt


def simulate(K=0.18, q_ref=1.0, q0=0.2, steps=40):
    q = np.empty(steps + 1)
    q[0] = q0
    for k in range(steps):
        q[k + 1] = q[k] + K * (q_ref - q[k])
    err = np.abs(q_ref - q)
    return q, err


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--K", type=float, default=0.18)
    ap.add_argument("--q-ref", type=float, default=1.0)
    ap.add_argument("--q0", type=float, default=0.2)
    ap.add_argument("--steps", type=int, default=40)
    ap.add_argument("--out", default="figure3_closedloop.png")
    args = ap.parse_args()

    q, err = simulate(args.K, args.q_ref, args.q0, args.steps)
    k = np.arange(len(q))

    fig, ax1 = plt.subplots(figsize=(6.5, 4.0))
    ax1.plot(k, q, "-o", ms=3, color="#1f4e79", label="Fused-stream quality $Q_F(k)$")
    ax1.axhline(args.q_ref, ls="--", color="#888888", lw=1, label="Target $Q_{ref}$")
    ax1.set_xlabel("Control iteration $k$")
    ax1.set_ylabel("Normalized fused-stream quality")
    ax1.set_ylim(0, 1.05)

    ax2 = ax1.twinx()
    ax2.semilogy(k, err + 1e-12, "-s", ms=3, color="#c0504d",
                 label="Absolute quality error $|Q_{ref}-Q_F(k)|$")
    ax2.set_ylabel("Absolute quality error (log scale)")

    lines = ax1.get_lines() + ax2.get_lines()
    ax1.legend(lines, [l.get_label() for l in lines], loc="center right", fontsize=8)
    ax1.set_title(f"Closed-loop convergence (K = {args.K})")
    fig.tight_layout()
    fig.savefig(args.out, dpi=300)
    print(f"Saved {args.out}")


if __name__ == "__main__":
    main()
