"""
Noise-variance estimation utilities.

Implements the Immerkaer (1996) fast noise-variance estimator used by the
precision-weighted Bayesian baseline in Section 10 of the manuscript.

Reference:
    J. Immerkaer, "Fast noise variance estimation,"
    Computer Vision and Image Understanding, 64(2), 300-302, 1996.
"""

import numpy as np
from scipy.signal import convolve2d


# Immerkaer's 3x3 Laplacian-difference mask. Its response to a smooth signal
# is ~zero, so its variance over the image is dominated by noise.
_IMMERKAER_MASK = np.array([[1, -2, 1],
                            [-2, 4, -2],
                            [1, -2, 1]], dtype=np.float64)

# Sum of squared mask coefficients (= 36), used to normalise the estimate.
_MASK_SS = float(np.sum(_IMMERKAER_MASK ** 2))


def immerkaer_noise_variance(img):
    """
    Estimate additive-noise variance of a single-band image.

    Parameters
    ----------
    img : 2-D float array
        Image, any range (computation is range-relative).

    Returns
    -------
    float
        Estimated noise variance sigma^2.
    """
    img = np.asarray(img, dtype=np.float64)
    if img.ndim != 2:
        raise ValueError("immerkaer_noise_variance expects a 2-D image.")

    response = convolve2d(img, _IMMERKAER_MASK, mode="valid")
    # Immerkaer's closed form: sigma^2 = sum(|response|)^2 * pi/2 / (36 * N)
    # The robust mean-absolute form below is numerically equivalent and is the
    # version most commonly used in fusion code.
    h, w = response.shape
    sigma = np.sum(np.abs(response)) * np.sqrt(np.pi / 2.0) / (6.0 * h * w)
    return float(sigma ** 2)
