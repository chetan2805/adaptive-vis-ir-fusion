import csv, numpy as np
from scipy import stats

FILES = {
    "RoadScene":  "/home/claude/results_roadscene.csv",
    "MSRS-day":   "/home/claude/results_msrs_day.csv",
    "MSRS-night": "/home/claude/results_msrs_night.csv",
}
ORDER = ["fixed_weight","pca","bayesian_immerkaer","proposed","gff","dwt"]
METRICS = ["EN","MI","SSIM","Qabf","VIF","SD","SF","w_ir","runtime_ms"]

def load(f):
    rows=[]
    for r in csv.DictReader(open(f)):
        for k in METRICS: r[k]=float(r[k])
        rows.append(r)
    return rows

data={k:load(v) for k,v in FILES.items()}

for ds,rows in data.items():
    n=len({r['image'] for r in rows})
    print(f"\n===== {ds}  (n={n} images) =====")
    print(f"{'method':<20}"+"".join(f"{m:>14}" for m in ["EN","MI","SSIM","Qabf","VIF","w_ir"]))
    for m in ORDER:
        sub=[r for r in rows if r['method']==m]
        if not sub: continue
        cells=[]
        for k in ["EN","MI","SSIM","Qabf","VIF","w_ir"]:
            v=np.array([r[k] for r in sub]); cells.append(f"{v.mean():.3f}\u00b1{v.std():.3f}")
        print(f"{m:<20}"+"".join(f"{c:>14}" for c in cells))

# Weight inversion table (proposed=saliency/local-variance vs bayesian=precision/Immerkaer)
print("\n===== WEIGHT INVERSION (mean per-pixel IR weight) =====")
print(f"{'dataset':<14}{'saliency(prop)':>16}{'precision(bayes)':>18}{'inverted?':>12}")
for ds,rows in data.items():
    ws=np.mean([r['w_ir'] for r in rows if r['method']=='proposed'])
    wp=np.mean([r['w_ir'] for r in rows if r['method']=='bayesian_immerkaer'])
    inv = "YES" if (ws-0.5)*(wp-0.5)<0 else "no"
    print(f"{ds:<14}{ws:>16.3f}{wp:>18.3f}{inv:>12}")

# Cohen dz for the inversion: per-image difference (saliency w_ir - precision w_ir)
print("\n===== INVERSION EFFECT SIZE (Cohen's d_z of saliency vs precision IR weight) =====")
for ds,rows in data.items():
    imgs=sorted({r['image'] for r in rows})
    pby={r['image']:r['w_ir'] for r in rows if r['method']=='proposed'}
    bby={r['image']:r['w_ir'] for r in rows if r['method']=='bayesian_immerkaer'}
    d=np.array([pby[i]-bby[i] for i in imgs if i in pby and i in bby])
    dz=d.mean()/(d.std(ddof=1)+1e-12)
    print(f"{ds:<14} d_z={dz:+.2f}  (mean diff {d.mean():+.3f}, n={len(d)})")

# Best method per metric per dataset (higher is better for EN,MI,SSIM,Qabf,VIF)
print("\n===== LEADER PER METRIC =====")
for ds,rows in data.items():
    print(f"  {ds}:")
    for k in ["EN","MI","SSIM","Qabf","VIF"]:
        best=max(ORDER,key=lambda m:np.mean([r[k] for r in rows if r['method']==m]) if [r for r in rows if r['method']==m] else -1)
        val=np.mean([r[k] for r in rows if r['method']==best])
        pv=np.mean([r[k] for r in rows if r['method']=='proposed'])
        print(f"    {k:<6} leader={best:<18}({val:.3f})   proposed={pv:.3f}")
